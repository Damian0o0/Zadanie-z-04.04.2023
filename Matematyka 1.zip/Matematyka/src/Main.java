import Uklad_rownan.UkladRownan;
import Uklad_rownan.UkladRownan2x2;
import Uklad_rownan.UkladRownan3x3;

public class Main {
    public static void main(String[] args) {


        UkladRownan Uklad = new UkladRownan();
        UkladRownan2x2 Uklad2 = new UkladRownan2x2();
        UkladRownan3x3 Uklad3 = new UkladRownan3x3();

        System.out.println("Proszę o 5 😎🤙😎🤙😎🤙😎🤙😎🤙😎🤙😎🤙, więcej zadań nie dało rady zrobić :/");
    }
}

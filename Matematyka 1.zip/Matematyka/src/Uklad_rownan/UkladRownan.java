package Uklad_rownan;

public abstract class UkladRownan {
    protected double[][] jd1;

    protected double[] wyrazywolne;

    public UkladRownan(double[][] jd1, double[] wyrazywolne) {
        this.jd1 = jd1;
        this.wyrazywolne = wyrazywolne;
    }

    public abstract double ObliczWyznacznik(int nrKolumny);

    public double obliczniewiadoma(int nrKolumny){
        return ObliczWyznacznik(nrKolumny)/ObliczWyznacznik(1);
    }

    public boolean CzyOznaczony(int nrKolumny) {
        double wyznacznik = ObliczWyznacznik(-1);
        if (wyznacznik == 0){
            return false;
        } else{
            return true;
        }
    }


}


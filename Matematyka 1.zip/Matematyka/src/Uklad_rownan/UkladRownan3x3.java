package Uklad_rownan;
import Uklad_rownan.UkladRownan;
public abstract class UkladRownan3x3 extends UkladRownan{
    public UkladRownan3x3(double[][] jd1, double[] wyrazywolne) {
        super(jd1, wyrazywolne);
    }

    @Override
    public double ObliczWyznacznik(int nrKolumny){
        return 0;
    }
}

package Uklad_rownan;
import Uklad_rownan.UkladRownan;
public abstract class UkladRownan2x2 extends UkladRownan{
    public UkladRownan2x2(double[][] jd1, double[] wyrazywolne) {
        super(jd1, wyrazywolne);
    }

    @Override
    public double ObliczWyznacznik(int nrKolumny){
        return 0;
    }
}
